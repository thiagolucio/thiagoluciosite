import React, { Fragment, useState } from "react";
import "h8k-components";

import { image1, image2, image3, image4 } from "./assets/images";
import { Thumbs, Viewer } from "./components";

// import "./index.css";

const title = "Catalog Viewer";

function App() {
  const catalogsList = [
    {
      thumb: image1,
      image: image1,
    },
    {
      thumb: image2,
      image: image2,
    },
    {
      thumb: image3,
      image: image3,
    },
    {
      thumb: image4,
      image: image4,
    },
  ];

  const [catalogs] = useState([...catalogsList]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [slideTimer, setSlideTimer] = useState(null);
  const [slideDuration] = useState(3000);

  const handleThumbClick = (index) => {
    setActiveIndex(index);
  };

  const nextSlide = () => {
    const nextIndex = (activeIndex + 1) % catalogs.length;
    setActiveIndex(nextIndex);
  };

  const prevSlide = () => {
    const prevIndex = (activeIndex - 1 + catalogs.length) % catalogs.length;
    setActiveIndex(prevIndex);
  };

  const playSlide = () => {
    for (let i = 0; i < catalogs.length; i++) {
      setTimeout(() => {
        setActiveIndex(i);
      }, i * slideDuration);
    }
    clearInterval(slideTimer);
    setSlideTimer(null);
  };

  const didImageThumbnailClick = (index) => {
    setActiveIndex(index);
  };

  return (
    <Fragment>
      <h8k-navbar header={title}></h8k-navbar>
      <div className="layout-column justify-content-center mt-75">
        <div className="layout-row justify-content-center">
          <div className="card pt-25 bg-dark">
            <Viewer catalogImage={catalogs[activeIndex].image} />
            <div className="layout-row justify-content-center align-items-center mt-20">
              <button
                onClick={prevSlide}
                className="icon-only outlined"
                data-testid="prev-slide-btn">
                <i className="material-icons">arrow_back</i>
              </button>
              <Thumbs
                items={catalogs}
                currentIndex={activeIndex}
                onClick={didImageThumbnailClick}
              />
              <button
                onClick={nextSlide}
                className="icon-only outlined"
                data-testid="next-slide-btn">
                <i className="material-icons">arrow_forward</i>
              </button>
            </div>
          </div>
        </div>
        <div className="layout-row justify-content-center mt-25">
          <input
            type="checkbox"
            data-testid="toggle-slide-show-button"
            className="input-autoplay"
            onClick={playSlide}
          />
          <label className="ml-6 text-light">Start Slide Show</label>
        </div>
      </div>
    </Fragment>
  );
}

export default App;
