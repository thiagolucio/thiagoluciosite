import React from 'react';


function Viewer({ catalogImage }) {
  return (
    <div className='layout-row justify-content-center bg-dark'>
      <img 
        alt='catalog-view' 
        className='w-100' 
        src={catalogImage}
        data-testid='catalog-view' 
      />
    </div>
  )
}

export default Viewer

