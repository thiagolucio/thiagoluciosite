import image1 from './tea-light-candle.jpeg'
import image2 from './white-light-candle.jpg'
import image3 from './pink-light-candle.jpeg'
import image4 from './green-light-candle.jpeg'

export { image1, image2, image3, image4 }